{ base64 -w0 exploit; echo; echo __EOF__; cat -; } | nc -v HOST PORT
use this to send exploit to vm and launch task